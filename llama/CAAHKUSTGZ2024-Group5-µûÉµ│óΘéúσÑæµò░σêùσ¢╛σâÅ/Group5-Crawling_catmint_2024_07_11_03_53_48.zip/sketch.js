function setup() {
  createCanvas(600, 600);
}

function draw() {
  background(220);

  // 定义斐波那契数列的前两个数字
  let a = 0;
  let b = 1;

  // 设置起始角度和半径
  let angle = 0;
  let radius = 10;

  // 计算与鼠标位置相关的旋转角度
  let rotationAngle = map(mouseX, 0, width, -PI, PI);

  // 根据鼠标Y位置调整线条宽度
  let lineWidth = map(mouseY, 0, height, 1, 10);
  
  // 根据鼠标位置调整第一组螺旋的颜色
  let red1 = map(mouseX, 0, width, 0, 255);
  let green1 = map(700 - mouseY, 0, height, 0, 255); 
  // 对称的绿色值

  // 根据鼠标位置调整第二组螺旋的颜色
  let red2 = map(mouseX, 0, width, 0, 255);
  let green2 = map(700 - mouseY, 0, height, 0, 255); 
  // 对称的绿色值

  // 绘制第一组螺旋图案
  push();
  translate(width / 2, height / 2);
  rotate(rotationAngle);
  
  stroke(red1, green1, 0); // 设置线条颜色
  strokeWeight(lineWidth); 
  noFill();

  for (let i = 0; i < 10000; i++) {
    let r = radius * a;
    arc(0, 0, r, r, angle, angle + radians(137.5));

    // 更新斐波那契数列的数字
    let temp = a;
    a = b;
    b = temp + b;

    // 增加角度
    angle += radians(137.5);
  }

  pop();

  // 绘制第二组螺旋图案
  push();
  translate(width / 2, height / 2);
  rotate(rotationAngle);

  stroke(red2, green2, 0); 
  strokeWeight(lineWidth); 

  noFill();

  for (let i = 0; i < 10000; i++) {
    let r = radius * a;
    arc(0, 0, r, r, angle, angle + radians(137.5));

    // 更新斐波那契数列的数字
    let temp = a;
    a = b;
    b = temp + b;

    // 增加角度
    angle += radians(137.5);
  }

  pop();
}