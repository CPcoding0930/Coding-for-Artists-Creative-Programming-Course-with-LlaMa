let capture;
let pixelSize = 14;

function setup() {
  createCanvas(640, 480);
  capture = createCapture(VIDEO);
  capture.size(640, 480);
  capture.hide();
  noStroke();
}

function draw() {
  background(220);
  
  capture.loadPixels();
  
  for (let y = 0; y < capture.height; y += pixelSize) {
    for (let x = 0; x < capture.width; x += pixelSize) {
      // let i = (y * capture.width + x) * 4;
      // let r = capture.pixels[i];
      // let g = capture.pixels[i + 1];
      // let b = capture.pixels[i + 2];
      let i = (y * capture.width + x) * 4;
      let r = capture.pixels[i];
      let g = capture.pixels[i + 1];
      let b = capture.pixels[i + 2];
      
      // 改变颜色的公式
      let newR = min(r + 50, 255); // 增加红色分量，确保不超过255
      let newG = max(g - 50, 0);   // 减少绿色分量，确保不低于0
      let newB = 255 - b;          // 蓝色分量取反
      
      fill(newR, newG, newB);
      
      // fill(r, g, b);
      rect(x, y, pixelSize, pixelSize);
    }
  }
}
