let circles = [];
let numCircles = 200; // 初始圆圈数量
let prevMouseX, prevMouseY;
let maxSpeed = 50;
let fractalScale = 0.01; // 分形运动的缩放因子
let splitThreshold = 80; // 分裂的阈值
let mergeThreshold = 40; // 合并的阈值
let backgroundColor;
let backgroundChangeSpeed = 0.01; // 背景颜色变化的初始速度

function setup() {
  createCanvas(windowWidth, windowHeight);
  backgroundColor = color(0); // 初始化为黑色
  initCircles(numCircles);
  prevMouseX = mouseX;
  prevMouseY = mouseY;
}

function draw() {
  let speed = dist(mouseX, mouseY, prevMouseX, prevMouseY);
  let normalizedSpeed = map(speed, 0, maxSpeed, 1, 0); // 反转速度映射，使鼠标移动越慢，normalizedSpeed越大

  // 随机高频黑白闪烁
  if (random(1) > 0.5) {
    backgroundColor = color(255); // 白色
  } else {
    backgroundColor = color(0); // 黑色
  }
  background(backgroundColor, 25); // 使用半透明背景颜色，产生残影效果

  for (let i = 0; i < circles.length; i++) {
    let circle = circles[i];

    if (speed > 0) {
      // 根据鼠标速度调整圆圈速度、颜色和大小
      circle.x += circle.xSpeed * circle.speedFactor * normalizedSpeed * 10; // 调整速度变化，使鼠标移动越慢，变化越快
      circle.y += circle.ySpeed * circle.speedFactor * normalizedSpeed * 10; // 调整速度变化，使鼠标移动越慢，变化越快

      circle.color = color(
        random(255),
        random(255),
        random(255),
        random(100, 255)
      );

      circle.size = map(normalizedSpeed, 0, 1, 10, circle.sizeFactor);
    } else {
      // 鼠标静止时，圆圈进行分形运动
      circle.x = noise(circle.offsetX + frameCount * fractalScale) * width;
      circle.y = noise(circle.offsetY + frameCount * fractalScale) * height;

      // 分裂
      if (circle.size > splitThreshold) {
        let newSize = circle.size / 2;
        circle.size = newSize;
        circle.speedFactor *= 2; // 分裂后速度变快
        let newCircle = {
          x: circle.x + random(-newSize, newSize),
          y: circle.y + random(-newSize, newSize),
          size: newSize,
          color: color(random(255), random(255), random(255), random(100, 255)),
          xSpeed: random(-2, 2),
          ySpeed: random(-2, 2),
          speedFactor: circle.speedFactor,
          sizeFactor: circle.sizeFactor,
          shape: random(['ellipse', 'rect']),
          angle: random(TWO_PI),
          angleSpeed: random(-0.05, 0.05),
          offsetX: random(1000),
          offsetY: random(1000)
        };
        circles.push(newCircle);
      }

      // 合并
      for (let j = i + 1; j < circles.length; j++) {
        let otherCircle = circles[j];
        let d = dist(circle.x, circle.y, otherCircle.x, otherCircle.y);
        if (d < mergeThreshold) {
          circle.size += otherCircle.size;
          circle.speedFactor *= 0.5; // 合并后速度变慢
          circles.splice(j, 1);
          j--;
        }
      }
    }

    // 旋转物体
    circle.angle += circle.angleSpeed * normalizedSpeed * 10; // 调整旋转速度，使鼠标移动越慢，旋转越快

    push();
    translate(circle.x, circle.y);
    rotate(circle.angle);
    fill(circle.color);
    noStroke();
    if (circle.shape === 'ellipse') {
      ellipse(0, 0, circle.size);
    } else if (circle.shape === 'rect') {
      rect(-circle.size / 2, -circle.size / 2, circle.size, circle.size);
    }
    pop();
  }

  prevMouseX = mouseX;
  prevMouseY = mouseY;
}

function mousePressed() {
  // 随机化颜色、大小、速度和数量
  numCircles = random(100, 300);
  initCircles(numCircles);
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}

function initCircles(num) {
  circles = [];
  for (let i = 0; i < num; i++) {
    let circle = {
      x: random(width),
      y: random(height),
      size: random(10, 50),
      color: color(random(255), random(255), random(255), random(100, 255)),
      xSpeed: random(-2, 2),
      ySpeed: random(-2, 2),
      speedFactor: random(0.5, 2), // 随机速度因子
      sizeFactor: random(10, 100), // 随机大小因子
      shape: random(['ellipse', 'rect']), // 随机形状
      angle: random(TWO_PI), // 随机角度
      angleSpeed: random(-0.05, 0.05), // 随机旋转速度
      offsetX: random(1000), // 分形运动的x偏移
      offsetY: random(1000)  // 分形运动的y偏移
    };
    circles.push(circle);
  }
}
