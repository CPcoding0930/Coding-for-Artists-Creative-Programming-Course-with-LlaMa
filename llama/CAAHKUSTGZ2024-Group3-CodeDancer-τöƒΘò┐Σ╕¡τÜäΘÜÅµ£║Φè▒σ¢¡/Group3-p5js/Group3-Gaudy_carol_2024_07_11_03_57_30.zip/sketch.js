let plants = [];
let selectedPlant;

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(255);

  // Initialize plant data from backend API (e.g., Flask)
  fetch('/get_plants')
    .then(response => response.json())
    .then(data => {
      plants = data;
    });

  // Set initial selected plant
  selectedPlant = plants[Math.floor(Math.random() * plants.length)];
}

function draw() {
  background(255);

  // Draw the garden
  for (let i = 0; i < plants.length; i++) {
    const plant = plants[i];
    fill(plant.color);
    noStroke();
    ellipse(width / 2 + Math.cos(frameCount * 0.01) * (i * 50), height / 2, 30, 30);

    // Display plant name and growth rate
    textSize(18);
    textAlign(CENTER, CENTER);
    text(` ${plant.name} - Growth: ${plant.growth_rate}`, width / 2 + Math.cos(frameCount * 0.01) * (i * 50), height / 2 + 30);
  }

  // Display selected plant details
  if (selectedPlant) {
    fill(255, 255, 0);
    noStroke();
    rect(width / 2 - 100, height / 2 - 20, 200, 40);

    textSize(24);
    textAlign(CENTER, CENTER);
    text(` ${selectedPlant.name}`, width / 2, height / 2 + 10);

    // Watering button
    fill(0, 128, 0);
    noStroke();
    rect(width / 2 - 50, height / 2 + 60, 100, 30);

    textSize(18);
    textAlign(CENTER, CENTER);
    text('Water', width / 2, height / 2 + 80);
  }
}

function mousePressed() {
  // Select a new plant when clicked
  selectedPlant = plants[Math.floor(Math.random() * plants.length)];
}